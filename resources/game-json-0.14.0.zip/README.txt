PvZ2 Gardendless 0.14.0 original JSON resources

1352 JSON assets extracted from the game body, with author-supplied updates.
Objects/ZombieProps.json is synchronized with the author's json.zip.
Links.json uses the announcement and netdisk addresses from the author's Links.JSON.
Includes Features, Objects, levels, language data and other JSON resources.
For reference and editing; this archive is not an installable GP-Next datapack.
Files retain the game resource paths (the leading json/ is omitted).
MANIFEST.json records the release ZIP, author updates and individual JSON SHA-256 hashes.
