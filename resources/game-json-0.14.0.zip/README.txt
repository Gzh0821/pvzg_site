PvZ2 Gardendless 0.14.0 original JSON resources

1352 JSON assets extracted from the unmodified game body.
Includes Features, Objects, levels, language data and other JSON resources.
For reference and editing; this archive is not an installable GP-Next datapack.
Files retain the game resource paths (the leading json/ is omitted).
MANIFEST.json records the original release ZIP and individual JSON SHA-256 hashes.
