PvZ2 Gardendless 0.15.0 original JSON resources

1364 JSON assets extracted from the game body. Links.json uses the netdisk addresses in the author announcement.
Includes Features, Objects, levels, language data and other JSON resources.
This is a reference archive, not an installable datapack. See MANIFEST.json for source and hashes.
