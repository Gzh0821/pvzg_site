// @ts-check
export default {
    /** @param {import('../types/entity-startup').EntityStartupContext} ctx */
    startup(ctx) {
        const entities = ctx.registry.resolve('pvzge.entities', 'entities')
        entities.registerBehavior('example.entity-framework', 'pulse', (Base, { sounds }) => class extends Base {
            elapsed = 0
            /** @param {number} delta */
            specialPlantUpdate(delta) {
                this.elapsed += delta
                this.body.angle = Math.sin(this.elapsed * 3) * 8
            }
            /** @param {import('../types/entity-startup').EntityAnimationEvent} event */
            animationListener(event) {
                super.animationListener(event)
                const clip = sounds[event.name]
                if (clip) this.getComponent('cc.AudioSource').playOneShot(clip, 0.25)
            }
        })
        entities.registerBehavior('example.entity-framework', 'walker', (Base, { sounds }) => class extends Base {
            elapsed = 0
            /** @param {number} delta */
            specialZombieUpdate(delta) {
                this.elapsed += delta
                this.body.node.angle = Math.sin(this.elapsed * 3) * 8
            }
            /** @param {import('../types/entity-startup').EntityAnimationEvent} event */
            specialSoundEventListener(event) {
                const clip = sounds[event.name]
                if (clip) this.getComponent('cc.AudioSource').playOneShot(clip, 0.25)
            }
        })
    },
    /** @param {import('../types/gp-next-api').ModContext} ctx */
    setup(ctx) { ctx.log.info('实体模组已加载') },
}
