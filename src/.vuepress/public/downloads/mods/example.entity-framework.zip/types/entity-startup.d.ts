import type { StartupContext } from './gp-next-api'
export type NativeEntityClass = new (...args: any[]) => any
export interface EntityAnimationEvent { name: string }
export interface EntityService {
    registerBehavior(namespace: string, id: string, factory: (Base: NativeEntityClass, resources: {
        readonly sounds: Readonly<Record<string, any>>
    }) => NativeEntityClass): void
}
export interface EntityStartupContext extends Omit<StartupContext, 'registry'> {
    readonly registry: { resolve(provider: 'pvzge.entities', id: 'entities'): EntityService }
}
