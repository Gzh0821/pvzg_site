//#region mods/entities/src/pack-path.js
function normalizeModRelativePath(input, options = {}) {
	const value = String(input || "").trim().replace(/\\/g, "/");
	if (!value) throw new Error(`${options.label || "path"} is required`);
	if (value.startsWith("/") || /^[a-zA-Z]:/.test(value) || value.includes("\0")) throw new Error(`${options.label || "path"} must be relative to the pack root`);
	const parts = value.split("/").filter((part) => part && part !== ".");
	if (parts.some((part) => part === "..")) throw new Error(`${options.label || "path"} cannot contain parent-directory segments`);
	const normalized = parts.join("/");
	if (!normalized) throw new Error(`${options.label || "path"} is required`);
	return normalized;
}
//#endregion
//#region mods/entities/src/entity-content-descriptor.js
var preparedMedia = /* @__PURE__ */ new WeakMap();
var fail$1 = (message) => {
	throw new Error(`Entity content: ${message}`);
};
var object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
function freeze$1(value) {
	if (value && typeof value === "object") {
		Object.values(value).forEach(freeze$1);
		Object.freeze(value);
	}
	return value;
}
function localId(value, label) {
	if (typeof value !== "string" || !/^[a-zA-Z][a-zA-Z0-9_.-]*$/.test(value)) fail$1(`${label} must be a local identifier`);
	return value;
}
function path(value, extension) {
	if (typeof value !== "string") fail$1("resource path must be a string");
	const result = normalizeModRelativePath(value, { label: "entity resource path" });
	if (!result.toLowerCase().endsWith(extension)) fail$1(`expected ${extension} resource: ${result}`);
	return result;
}
function bytes(snapshot, name) {
	const value = snapshot.readBytes(name);
	if (!value?.length) fail$1(`missing or empty resource: ${name}`);
	return value;
}
function json(snapshot, name) {
	const text = snapshot.readText(name);
	if (text === null) fail$1(`missing resource: ${name}`);
	const data = JSON.parse(text);
	if (!object(data)) fail$1(`expected JSON object: ${name}`);
	return data;
}
function pngSize(data) {
	if (data.length < 33 || [
		137,
		80,
		78,
		71,
		13,
		10,
		26,
		10
	].some((byte, i) => data[i] !== byte)) fail$1("invalid PNG header");
	const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
	if (view.getUint32(8) !== 13 || view.getUint32(12) !== 1229472850) fail$1("missing PNG IHDR");
	const width = view.getUint32(16), height = view.getUint32(20);
	if (!width || !height) fail$1("invalid PNG dimensions");
	return {
		width,
		height
	};
}
function validateWav(data) {
	const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
	if (data.length < 12 || view.getUint32(0) !== 1380533830 || view.getUint32(8) !== 1463899717 || view.getUint32(4, true) + 8 !== data.length) fail$1("invalid WAV RIFF header");
	let offset = 12, format = false, samples = false;
	while (offset + 8 <= data.length) {
		const kind = view.getUint32(offset), size = view.getUint32(offset + 4, true);
		if (offset + 8 + size > data.length) fail$1("truncated WAV chunk");
		if (kind === 1718449184) format = size >= 16;
		if (kind === 1684108385) samples = size > 0;
		offset += 8 + size + size % 2;
	}
	if (offset !== data.length || !format || !samples) fail$1("missing WAV format or sample data");
}
function validateDragonBones(skeleton, atlas, armatureName, size) {
	if (skeleton.version !== "5.5") fail$1("only DragonBones 5.5 is supported by this adapter");
	const armatures = skeleton.armature?.filter((armature) => armature.name === armatureName);
	if (armatures?.length !== 1) fail$1(`missing or duplicate armature: ${armatureName}`);
	if (atlas.width !== size.width || atlas.height !== size.height || !Array.isArray(atlas.SubTexture) || !atlas.SubTexture.length) fail$1("atlas dimensions or regions do not match PNG");
	const regions = /* @__PURE__ */ new Set();
	for (const region of atlas.SubTexture) {
		if (!region.name || regions.has(region.name)) fail$1("duplicate or unnamed atlas region");
		if (![
			region.x,
			region.y,
			region.width,
			region.height
		].every(Number.isFinite) || region.x < 0 || region.y < 0 || region.width <= 0 || region.height <= 0 || region.x + region.width > size.width || region.y + region.height > size.height) fail$1("atlas region outside PNG");
		regions.add(region.name);
	}
	const armature = armatures[0];
	let displays = 0;
	for (const skin of armature.skin || []) for (const slot of skin.slot || []) for (const display of slot.display || []) {
		if (display.type !== void 0 && display.type !== "image" && display.type !== 0) fail$1("only DragonBones image displays are supported");
		if (!regions.has(display.path || display.name)) fail$1(`display has no atlas region: ${display.path || display.name}`);
		displays++;
	}
	if (!displays || !Array.isArray(armature.animation)) fail$1("armature needs image displays and animations");
	const animations = /* @__PURE__ */ new Map();
	for (const animation of armature.animation) {
		if (!animation.name || animations.has(animation.name)) fail$1("duplicate or unnamed animation");
		animations.set(animation.name, animation);
	}
	return animations;
}
function localized(value, label) {
	if (!object(value) || !Object.keys(value).length || Object.values(value).some((text) => typeof text !== "string" || !text.trim())) fail$1(`${label} needs non-empty localized text`);
	return value;
}
function point(value, label, positive = false) {
	if (!object(value) || ![value.x, value.y].every(Number.isFinite) || positive && (value.x <= 0 || value.y <= 0)) fail$1(`invalid ${label}`);
	return {
		x: value.x,
		y: value.y
	};
}
function almanacData(source, kind) {
	if (source === void 0) return null;
	if (!object(source)) fail$1("almanac must be an object");
	const data = {
		Introduction: localized(source.Introduction, "almanac.Introduction"),
		Chat: localized(source.Chat, "almanac.Chat"),
		Elements: source.Elements === void 0 ? [] : source.Elements,
		Special: source.Special === void 0 ? [] : source.Special,
		DisplayOffset: source.DisplayOffset === void 0 ? {
			x: 0,
			y: 0
		} : point(source.DisplayOffset, "almanac.DisplayOffset")
	};
	if (kind === "plant") data.BriefIntroduction = localized(source.BriefIntroduction, "almanac.BriefIntroduction");
	else data.DisplayScale = source.DisplayScale === void 0 ? {
		x: 1,
		y: 1
	} : point(source.DisplayScale, "almanac.DisplayScale", true);
	if (!Array.isArray(data.Elements) || !Array.isArray(data.Special)) fail$1("almanac Elements and Special must be arrays");
	if (kind === "zombie" && data.Elements.length > 2) fail$1("zombie almanac supports at most two elements");
	data.Elements = data.Elements.map((element) => {
		if (!object(element)) fail$1("invalid almanac element");
		if (kind === "plant") {
			if (![
				"SUNCOST",
				"RECHARGE",
				"TOUGHNESS"
			].includes(element.TYPE)) fail$1("unsupported plant almanac element");
			return { TYPE: element.TYPE };
		}
		if (!["TOUGHNESS", "SPEED"].includes(element.TYPE) || !Number.isFinite(element.PROGRESS) || element.PROGRESS < 0 || element.PROGRESS > 1) fail$1("invalid zombie almanac element");
		return {
			TYPE: element.TYPE,
			SORT: localized(element.SORT, "almanac element SORT"),
			PROGRESS: element.PROGRESS
		};
	});
	data.Special = data.Special.map((entry) => {
		if (!object(entry)) fail$1("invalid almanac Special entry");
		return {
			NAME: localized(entry.NAME, "almanac Special NAME"),
			DESCRIPTION: localized(entry.DESCRIPTION, "almanac Special DESCRIPTION")
		};
	});
	return data;
}
function prepareEntityContent(pack, snapshot) {
	const text = snapshot.readText("content/entities.json");
	if (text === null) return null;
	const namespace = pack?.meta?.uuid;
	if (typeof namespace !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9_.-]{2,127}$/.test(namespace)) fail$1("package requires a stable namespace");
	if (pack.contentDigest && pack.contentDigest !== snapshot.digest) fail$1("package snapshot digest mismatch");
	const descriptor = JSON.parse(text);
	if (!object(descriptor) || descriptor.formatVersion !== 1 || !Array.isArray(descriptor.resources) || !Array.isArray(descriptor.entities)) fail$1("expected formatVersion 1 with resources and entities arrays");
	const resources = [], media = /* @__PURE__ */ new Map(), animationSets = /* @__PURE__ */ new Map();
	for (const source of descriptor.resources) {
		if (!object(source)) fail$1("resource must be an object");
		const id = localId(source.id, "resource id");
		if (media.has(id)) fail$1(`duplicate resource: ${id}`);
		if (source.kind === "dragonbones") {
			const resource = {
				id,
				kind: source.kind,
				skeleton: path(source.skeleton, ".json"),
				atlas: path(source.atlas, ".json"),
				texture: path(source.texture, ".png"),
				armature: localId(source.armature, "armature")
			};
			const skeleton = json(snapshot, resource.skeleton), atlas = json(snapshot, resource.atlas), image = bytes(snapshot, resource.texture);
			const size = pngSize(image);
			animationSets.set(id, validateDragonBones(skeleton, atlas, resource.armature, size));
			media.set(id, {
				skeleton: freeze$1(skeleton),
				atlas: freeze$1(atlas),
				image,
				...size
			});
			resources.push(resource);
		} else if (source.kind === "audio") {
			const resource = {
				id,
				kind: source.kind,
				path: path(source.path, ".wav")
			};
			const audio = bytes(snapshot, resource.path);
			validateWav(audio);
			media.set(id, { audio });
			resources.push(resource);
		} else fail$1(`unsupported resource kind: ${source.kind}`);
	}
	const identities = /* @__PURE__ */ new Set();
	const entities = descriptor.entities.map((source) => {
		if (!object(source)) fail$1("entity must be an object");
		const id = localId(source.id, "entity id");
		if (identities.has(id)) fail$1(`duplicate entity: ${id}`);
		identities.add(id);
		if (!["plant", "zombie"].includes(source.kind)) fail$1(`unsupported entity kind: ${source.kind}`);
		if (typeof source.behavior !== "string") fail$1("behavior must be a string");
		const parts = source.behavior.split(":");
		if (parts.length === 1) localId(source.behavior, "behavior");
		else {
			const [provider, behavior] = parts;
			if (parts.length !== 2 || !/^[a-zA-Z0-9][a-zA-Z0-9_.-]{2,127}$/.test(provider)) fail$1("invalid behavior provider");
			localId(behavior, "behavior");
			if (provider !== namespace && !(Array.isArray(pack.meta.depends) && pack.meta.depends.includes(provider))) fail$1(`behavior provider requires a direct dependency: ${provider}`);
		}
		const animations = animationSets.get(source.visual);
		if (!animations) fail$1(`entity visual is not a local DragonBones resource: ${source.visual}`);
		for (const name of source.kind === "plant" ? ["Idle", "Death"] : [
			"Idle",
			"Walk",
			"Eat",
			"Death"
		]) if (!animations.has(name)) fail$1(`missing native animation: ${name}`);
		const death = animations.get("Death");
		if (death.playTimes !== 1) fail$1("Death animation must complete once");
		if (source.kind === "zombie" && !death.frame?.some((frame) => frame.event === "die")) fail$1("zombie Death requires a die frame event");
		if (!object(source.feature) || !object(source.properties)) fail$1("entity needs explicit feature and properties objects");
		for (const key of [
			"ID",
			"CODENAME",
			"PROPS",
			"RES",
			"ALMANAC"
		]) if (Object.hasOwn(source.feature, key)) fail$1(`feature.${key} is reserved for native registration`);
		const sounds = source.sounds ?? {};
		if (!object(sounds)) fail$1("sounds must map event names to local audio resources");
		for (const resource of Object.values(sounds)) if (!resources.some((item) => item.id === resource && item.kind === "audio")) fail$1(`sound is not a local audio resource: ${resource}`);
		const almanac = almanacData(source.almanac, source.kind);
		if (source.listed !== void 0 && typeof source.listed !== "boolean") fail$1("listed must be a boolean");
		const listed = source.listed === true;
		if (listed && !almanac) fail$1("listed entities require independent almanac data");
		return {
			almanac,
			listed,
			id,
			key: `${namespace}:${id}`,
			kind: source.kind,
			behavior: source.behavior,
			visual: source.visual,
			feature: source.feature,
			properties: source.properties,
			sounds
		};
	});
	const prepared = freeze$1({
		namespace,
		contentDigest: snapshot.digest,
		formatVersion: 1,
		resources,
		entities
	});
	preparedMedia.set(prepared, media);
	return prepared;
}
/** Private decoder input; copies preserve the validated preparation. */
function readPreparedEntityResource(prepared, id) {
	const value = preparedMedia.get(prepared)?.get(id);
	if (!value) fail$1("resource does not belong to a prepared descriptor");
	return value.audio ? { audio: value.audio.slice() } : {
		...value,
		image: value.image.slice()
	};
}
//#endregion
//#region mods/entities/src/entity-content-assets.js
function abortError() {
	return Object.assign(/* @__PURE__ */ new Error("Entity resource preparation aborted"), { name: "AbortError" });
}
async function decodeEntityContentResources(prepared, { cc, signal, platform = {} }) {
	const instanceToken = crypto.randomUUID();
	const createObjectURL = platform.createObjectURL || ((blob) => URL.createObjectURL(blob));
	const revokeObjectURL = platform.revokeObjectURL || ((url) => URL.revokeObjectURL(url));
	const createImage = platform.createImage || (() => new Image());
	const cleanups = [];
	const resources = /* @__PURE__ */ new Map();
	const consumers = /* @__PURE__ */ new Map();
	let consumerRevision = 0;
	let disposed = false;
	const assertActive = () => {
		if (signal?.aborted) throw abortError();
	};
	const dispose = () => {
		if (disposed) return false;
		if (consumers.size) throw Object.assign(/* @__PURE__ */ new Error("Entity resources still have native consumers"), { code: "ENTITY_RESOURCES_IN_USE" });
		disposed = true;
		resources.clear();
		const errors = [];
		for (const cleanup of cleanups.splice(0).reverse()) try {
			cleanup();
		} catch (error) {
			errors.push(error);
		}
		if (errors.length) throw new AggregateError(errors, "Entity resource cleanup failed");
		return true;
	};
	const own = (asset) => {
		cleanups.push(() => asset.destroy());
		return asset;
	};
	const urlFor = (bytes, type) => {
		const url = createObjectURL(new Blob([bytes], { type }));
		cleanups.push(() => revokeObjectURL(url));
		return url;
	};
	const wait = (promise, releaseLate = () => {}) => new Promise((resolve, reject) => {
		let settled = false;
		const abort = () => {
			if (settled) return;
			settled = true;
			signal?.removeEventListener("abort", abort);
			reject(abortError());
		};
		signal?.addEventListener("abort", abort, { once: true });
		if (signal?.aborted) abort();
		Promise.resolve(promise).then((value) => {
			if (settled) {
				try {
					releaseLate(value);
				} catch (error) {
					console.error("[GP Next:entity-content] Late asset cleanup failed", error);
				}
				return;
			}
			settled = true;
			signal?.removeEventListener("abort", abort);
			resolve(value);
		}, (error) => {
			if (settled) return;
			settled = true;
			signal?.removeEventListener("abort", abort);
			reject(error);
		});
	});
	try {
		assertActive();
		if (!prepared || !Array.isArray(prepared.resources)) throw new Error("Expected prepared entity content");
		for (const resource of prepared.resources) {
			assertActive();
			const data = readPreparedEntityResource(prepared, resource.id);
			if (resource.kind === "dragonbones") {
				if (!cc?.ImageAsset || !cc?.Texture2D || !cc.dragonBones?.DragonBonesAsset || !cc.dragonBones?.DragonBonesAtlasAsset) throw new Error("Full Cocos DragonBones asset module is unavailable");
				const image = createImage();
				const url = urlFor(data.image, "image/png");
				cleanups.push(() => {
					image.src = "";
				});
				image.src = url;
				await wait(image.decode());
				assertActive();
				if (image.naturalWidth !== data.width || image.naturalHeight !== data.height) throw new Error("Decoded PNG dimensions differ from prepared atlas");
				const imageAsset = own(new cc.ImageAsset(image));
				const texture = own(new cc.Texture2D());
				texture.image = imageAsset;
				const atlas = own(new cc.dragonBones.DragonBonesAtlasAsset());
				const skeleton = own(new cc.dragonBones.DragonBonesAsset());
				const cacheName = `gpn:${prepared.namespace}:${resource.id}:${prepared.contentDigest}:${instanceToken}`;
				atlas.atlasJson = JSON.stringify({
					...data.atlas,
					name: cacheName
				});
				atlas.texture = texture;
				skeleton.dragonBonesJson = JSON.stringify({
					...data.skeleton,
					name: cacheName
				});
				resources.set(resource.id, Object.freeze({
					kind: resource.kind,
					armature: resource.armature,
					image: imageAsset,
					texture,
					atlas,
					skeleton
				}));
			} else {
				if (!cc?.AudioClip || !cc.assetManager?.loadRemote || !cc.assetManager?.releaseAsset) throw new Error("Cocos audio asset loader is unavailable");
				const url = urlFor(data.audio, "audio/wav");
				const release = (clip) => {
					if (clip) cc.assetManager.releaseAsset(clip);
				};
				const clip = await wait(new Promise((resolve, reject) => {
					cc.assetManager.loadRemote(url, { ext: ".wav" }, (error, asset) => {
						if (error) {
							try {
								release(asset);
							} catch (cleanupError) {
								reject(new AggregateError([error, cleanupError], "Audio load and cleanup failed"));
								return;
							}
							reject(error);
						} else resolve(asset);
					});
				}), release);
				cleanups.push(() => release(clip));
				assertActive();
				if (!(clip instanceof cc.AudioClip) || !(clip.getDuration() > 0)) throw new Error("WAV did not decode to a non-empty AudioClip");
				resources.set(resource.id, Object.freeze({
					kind: resource.kind,
					clip
				}));
			}
		}
		assertActive();
		return Object.freeze({
			namespace: prepared.namespace,
			contentDigest: prepared.contentDigest,
			get(id) {
				if (disposed) throw new Error("Entity resources are disposed");
				return resources.get(id) || null;
			},
			retain({ entityId, kind, resourceIds }) {
				if (disposed) throw new Error("Entity resources are disposed");
				if (typeof entityId !== "string" || !entityId.startsWith(`${prepared.namespace}:`) || !["native-prefab", "native-icon"].includes(kind) || !Array.isArray(resourceIds) || !resourceIds.length || resourceIds.some((id) => !resources.has(id))) throw new Error("Invalid native resource consumer");
				const key = Symbol();
				consumers.set(key, Object.freeze({
					provider: prepared.namespace,
					providerDigest: prepared.contentDigest,
					instanceToken,
					entityId,
					kind,
					resourceIds: Object.freeze([...new Set(resourceIds)])
				}));
				consumerRevision++;
				return () => {
					if (!consumers.delete(key)) return false;
					consumerRevision++;
					return true;
				};
			},
			getConsumers() {
				return Object.freeze({
					domain: "entity-resources",
					complete: false,
					revision: consumerRevision,
					references: Object.freeze([...consumers.values()])
				});
			},
			dispose
		});
	} catch (error) {
		try {
			dispose();
		} catch (cleanupError) {
			throw new AggregateError([error, cleanupError], "Entity resource preparation and cleanup failed");
		}
		throw error;
	}
}
//#endregion
//#region mods/entities/src/entity-native-plan.js
var plain = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
var freeze = (value) => {
	if (value && typeof value === "object") {
		Object.values(value).forEach(freeze);
		Object.freeze(value);
	}
	return value;
};
var fail = (code, message) => {
	throw Object.assign(new Error(message), { code });
};
var hex = (text) => [...new TextEncoder().encode(text)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
var codenameFor = (namespace, id) => `gpn_${hex(namespace)}_${hex(id)}`;
function merge(base, override) {
	const result = structuredClone(base);
	for (const [key, value] of Object.entries(override)) {
		if ([
			"__proto__",
			"constructor",
			"prototype"
		].includes(key)) fail("ENTITY_DATA_INVALID", "Unsafe native data key");
		result[key] = plain(value) && plain(result[key]) ? merge(result[key], value) : structuredClone(value);
	}
	return result;
}
function readBaseline(baseline, kind) {
	const isPlant = kind === "plant";
	const rows = baseline[`${kind}Features`]?.[isPlant ? "PLANTS" : "ZOMBIES"];
	const objects = baseline[`${kind}Props`]?.objects;
	const name = isPlant ? "peashooter" : "tutorial";
	if (!Array.isArray(rows) || !rows.length || !Array.isArray(objects)) fail("ENTITY_BASELINE_INVALID", `Missing ${kind} native baseline`);
	const names = /* @__PURE__ */ new Set();
	for (const row of rows) {
		if (!plain(row) || typeof row.CODENAME !== "string" || !row.CODENAME || names.has(row.CODENAME)) fail("ENTITY_BASELINE_INVALID", `Invalid or duplicate ${kind} codename`);
		names.add(row.CODENAME);
	}
	const feature = rows.find((row) => row.CODENAME === name);
	const alias = /^RTID\(([^@()]+)@(PlantProps|ZombieProps)\)$/.exec(feature?.PROPS || "");
	const matches = alias && alias[2] === (isPlant ? "PlantProps" : "ZombieProps") ? objects.filter((item) => item.objclass === (isPlant ? "PlantProperties" : "ZombieProperties") && item.aliases?.includes(alias[1])) : [];
	if (matches.length !== 1 || !plain(matches[0].objdata) || !plain(feature.NAME) || typeof feature.OBTAINWORLD !== "string" || typeof feature.ALMANAC !== "string" || isPlant && (!Array.isArray(feature.TAGS) || !plain(feature.RES)) || !isPlant && typeof feature.RES !== "string") fail("ENTITY_BASELINE_INVALID", `Invalid ${kind} ordinary template`);
	const properties = matches[0].objdata;
	for (const key of isPlant ? [
		"Toughness",
		"SunCost",
		"Cooldown"
	] : [
		"Toughness",
		"WalkSPS",
		"EatDPS"
	]) if (!Number.isFinite(properties[key]) || properties[key] < 0) fail("ENTITY_BASELINE_INVALID", `Invalid ${kind} template ${key}`);
	return {
		rows,
		names,
		feature,
		properties
	};
}
function planNativeEntities({ preparedDescriptors, baseline, previousLedger = [], dataLedger = [] }) {
	const bases = {
		plant: readBaseline(baseline, "plant"),
		zombie: readBaseline(baseline, "zombie")
	};
	const previous = /* @__PURE__ */ new Map(), previousNames = /* @__PURE__ */ new Map(), previousSlots = /* @__PURE__ */ new Set();
	for (const entry of previousLedger) {
		if (!plain(entry) || typeof entry.id !== "string" || !entry.id || !bases[entry.kind] || typeof entry.codename !== "string" || !entry.codename || !Number.isSafeInteger(entry.engineId) || entry.engineId < 0 || previous.has(entry.id) || previousNames.has(`${entry.kind}:${entry.codename}`) || previousSlots.has(`${entry.kind}:${entry.engineId}`)) fail("ENTITY_LEDGER_INVALID", "Invalid or conflicting previous entity identity");
		previous.set(entry.id, entry);
		previousNames.set(`${entry.kind}:${entry.codename}`, entry.id);
		previousSlots.add(`${entry.kind}:${entry.engineId}`);
	}
	const inputs = /* @__PURE__ */ new Map(), allNames = new Set(Object.entries(bases).flatMap(([kind, base]) => [...base.names].map((name) => `${kind}:${name}`)));
	for (const descriptor of preparedDescriptors) for (const entity of descriptor.entities) {
		const key = `${descriptor.namespace}:${entity.id}`;
		if (entity.key !== key || !bases[entity.kind] || !plain(entity.feature) || !plain(entity.properties) || inputs.has(key)) fail("ENTITY_IDENTITY_CONFLICT", `Invalid or duplicate entity: ${key}`);
		const codename = codenameFor(descriptor.namespace, entity.id);
		const nameKey = `${entity.kind}:${codename}`;
		if (allNames.has(nameKey)) fail("ENTITY_IDENTITY_CONFLICT", `Native codename collision: ${key}`);
		if (previousNames.has(nameKey) && previousNames.get(nameKey) !== key) fail("ENTITY_IDENTITY_CONFLICT", `Previous codename belongs to another identity: ${key}`);
		allNames.add(nameKey);
		const prior = previous.get(key);
		if (prior && (prior.kind !== entity.kind || prior.codename !== codename)) fail("ENTITY_IDENTITY_CONFLICT", `Previous identity changed: ${key}`);
		for (const field of [
			"ID",
			"CODENAME",
			"PROPS",
			"RES",
			"ALMANAC"
		]) if (Object.hasOwn(entity.feature, field)) fail("ENTITY_DATA_INVALID", `Reserved feature field: ${field}`);
		inputs.set(key, {
			descriptor,
			entity,
			key,
			codename,
			prior
		});
	}
	const entities = [], identityChanges = [];
	for (const kind of ["plant", "zombie"]) {
		const base = bases[kind];
		const items = [...inputs.values()].filter((item) => item.entity.kind === kind).sort((a, b) => {
			if (a.prior && b.prior) return a.prior.engineId - b.prior.engineId;
			if (a.prior) return -1;
			if (b.prior) return 1;
			return a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
		});
		for (const [offset, item] of items.entries()) {
			const { descriptor, entity, key, codename, prior } = item;
			const engineId = base.rows.length + offset;
			const feature = merge(base.feature, entity.feature);
			const properties = merge(base.properties, entity.properties);
			for (const field of kind === "plant" ? [
				"Toughness",
				"SunCost",
				"Cooldown"
			] : [
				"Toughness",
				"WalkSPS",
				"EatDPS"
			]) if (!Number.isFinite(properties[field]) || properties[field] < 0) fail("ENTITY_DATA_INVALID", `Invalid ${key} ${field}`);
			if (!plain(feature.NAME) || kind === "plant" && !Array.isArray(feature.TAGS)) fail("ENTITY_DATA_INVALID", `Invalid ${key} feature structure`);
			const propsType = kind === "plant" ? "PlantProps" : "ZombieProps";
			feature.CODENAME = codename;
			feature.PROPS = `RTID(${codename}@${propsType})`;
			feature._CARDSPRITENAME = "Idle";
			if (kind === "plant") {
				feature.ID = engineId;
				feature.COSTUME = 0;
				feature.RES = {
					Plant: codename,
					Disabled: codename
				};
			} else {
				feature.RES = codename;
				feature.SubZombieList = [];
			}
			const almanacRecord = entity.almanac ? {
				objclass: kind === "plant" ? "PlantAlmanacProperties" : "ZombieAlmanacProperties",
				aliases: [codename],
				objdata: structuredClone(entity.almanac)
			} : null;
			if (entity.listed && !almanacRecord) fail("ENTITY_DATA_INVALID", `Listed entity needs independent almanac: ${key}`);
			if (almanacRecord) feature.ALMANAC = `RTID(${codename}@${kind === "plant" ? "PlantAlmanac" : "ZombieAlmanac"})`;
			else delete feature.ALMANAC;
			const typeRecord = {
				[kind === "plant" ? "PlantBasedOn" : "ZombieBasedOn"]: codename,
				Properties: feature.PROPS
			};
			entities.push({
				id: key,
				namespace: descriptor.namespace,
				localId: entity.id,
				kind,
				engineId,
				codename,
				contentDigest: descriptor.contentDigest,
				behavior: entity.behavior,
				visual: entity.visual,
				sounds: structuredClone(entity.sounds),
				feature,
				properties,
				typeRecord,
				listed: entity.listed === true,
				almanacRecord,
				almanac: {
					ready: !!almanacRecord,
					source: almanacRecord ? "owned" : "absent",
					reference: feature.ALMANAC ?? null
				}
			});
			if (prior && prior.engineId !== engineId) identityChanges.push({
				id: key,
				kind,
				previousEngineId: prior.engineId,
				engineId,
				reason: "native-baseline-or-contiguous-order-changed"
			});
		}
	}
	const ledger = entities.map(({ id, kind, engineId, codename }) => ({
		id,
		kind,
		engineId,
		codename
	}));
	const ids = new Set(ledger.map((entry) => entry.id));
	for (const entry of dataLedger) {
		if (entry.origin !== "data" || !bases[entry.kind] || bases[entry.kind].rows[entry.engineId]?.CODENAME !== entry.codename || entry.id !== `data:${entry.kind}:${hex(entry.codename)}` || ids.has(entry.id)) fail("ENTITY_LEDGER_INVALID", "Invalid data entity ledger");
		ids.add(entry.id);
		const prior = previous.get(entry.id);
		if (prior && (prior.kind !== entry.kind || prior.codename !== entry.codename)) fail("ENTITY_IDENTITY_CONFLICT", "Data entity identity changed");
		if (prior && prior.engineId !== entry.engineId) identityChanges.push({
			id: entry.id,
			kind: entry.kind,
			previousEngineId: prior.engineId,
			engineId: entry.engineId,
			reason: "data-array-order-changed"
		});
		ledger.push(structuredClone(entry));
	}
	return freeze({
		entities,
		ledger,
		removed: previousLedger.filter((entry) => !ids.has(entry.id)).map((entry) => structuredClone(entry)),
		identityChanges,
		baselineCounts: {
			plant: bases.plant.rows.length,
			zombie: bases.zombie.rows.length
		}
	});
}
//#endregion
//#region mods/entities/src/entity-native-assets.js
function prepareNativeEntityAssets(plan, { cc, native, decodedOwners, behaviorFactories }) {
	const PrefabInfo = native?.PrefabInfo;
	if (typeof PrefabInfo !== "function") throw new Error("Native PrefabInfo metadata class is unavailable");
	if (!cc?.Node || !cc.Prefab || !cc.UITransform || !cc.dragonBones?.ArmatureDisplay || !cc._decorator?.ccclass || !cc.js?.unregisterClass) throw new Error("Native prefab construction API is unavailable");
	const records = /* @__PURE__ */ new Map(), cleanups = [];
	const releaseMedia = [];
	let state = "prepared";
	const token = crypto.randomUUID();
	const dispose = () => {
		if (state === "in-use") throw Object.assign(/* @__PURE__ */ new Error("Published entity assets require restart"), { code: "ENTITY_RESTART_REQUIRED" });
		if (state === "disposed") return false;
		state = "disposed";
		records.clear();
		const errors = [];
		for (const cleanup of cleanups.splice(0).reverse()) try {
			cleanup();
		} catch (error) {
			errors.push(error);
		}
		if (errors.length) throw new AggregateError(errors, "Native entity asset cleanup failed");
		for (const release of releaseMedia.splice(0)) release();
		return true;
	};
	const node = (name) => {
		const result = new cc.Node(name);
		cleanups.push(() => result.destroy());
		return result;
	};
	const build = (entity, visual, Class, displayOnly) => {
		const dimensions = JSON.parse(visual.atlas.atlasJson);
		if (!(dimensions.width > 0) || !(dimensions.height > 0)) throw new Error("Native visual has invalid dimensions");
		const root = node(`gpn:${entity.id}:${entity.contentDigest}:${token}:${displayOnly ? "display" : "entity"}`);
		root.addComponent(cc.UITransform).setContentSize(dimensions.width, dimensions.height);
		const body = new cc.Node("Body");
		body.parent = root;
		body.addComponent(cc.UITransform).setContentSize(dimensions.width, dimensions.height);
		const db = body.addComponent(cc.dragonBones.ArmatureDisplay);
		db._dragonAsset = visual.skeleton;
		db._dragonAtlasAsset = visual.atlas;
		db._armatureName = visual.armature;
		db.animationName = "Idle";
		if (entity.kind === "plant") root.addComponent(native.AnimationController);
		if (!displayOnly) {
			if (Object.keys(entity.sounds || {}).length) {
				if (!cc.AudioSource) throw new Error("Native AudioSource is unavailable");
				root.addComponent(cc.AudioSource);
			}
			const component = root.addComponent(Class);
			if (entity.kind === "zombie") component.body = body.addComponent(native.BodyGrouper);
		}
		const prefab = new cc.Prefab();
		cleanups.push(() => prefab.destroy());
		prefab.name = root.name;
		prefab.data = root;
		const info = new PrefabInfo();
		info.asset = prefab;
		info.root = root;
		root._prefab = info;
		return prefab;
	};
	try {
		for (const entity of plan.entities) {
			if (!["plant", "zombie"].includes(entity.kind) || records.has(entity.id)) throw new Error("Invalid or duplicate planned entity");
			const owner = decodedOwners.get(entity.namespace);
			if (!owner || owner.namespace !== entity.namespace || owner.contentDigest !== entity.contentDigest) throw new Error(`Decoded resource identity differs: ${entity.id}`);
			const visual = owner.get(entity.visual);
			if (visual?.kind !== "dragonbones") throw new Error(`Missing native visual: ${entity.id}`);
			const sounds = Object.create(null);
			for (const [eventName, id] of Object.entries(entity.sounds || {})) {
				const sound = owner.get(id);
				if (sound?.kind !== "audio" || !sound.clip) throw new Error(`Missing native sound: ${entity.id}`);
				sounds[eventName] = sound.clip;
			}
			releaseMedia.push(owner.retain({
				entityId: entity.id,
				kind: "native-prefab",
				resourceIds: [entity.visual, ...Object.values(entity.sounds || {})]
			}));
			const context = Object.freeze({ sounds: Object.freeze(sounds) });
			const Base = entity.kind === "plant" ? native.Plant : native.Zombie;
			if (typeof Base !== "function" || typeof native.AnimationController !== "function" || typeof native.BodyGrouper !== "function") throw new Error("Native entity classes unavailable");
			const behaviorKey = entity.behavior.includes(":") ? entity.behavior : `${entity.namespace}:${entity.behavior}`;
			const factory = behaviorFactories.get(behaviorKey);
			if (typeof factory !== "function") throw new Error(`Missing entity behavior: ${entity.id}`);
			const Behavior = factory(Base, context);
			if (typeof Behavior !== "function" || Behavior === Base || !(Behavior.prototype instanceof Base)) throw new Error(`Behavior must return a native subclass: ${entity.id}`);
			class OwnedBehavior extends Behavior {}
			cleanups.push(() => cc.js.unregisterClass(OwnedBehavior));
			cc._decorator.ccclass(`gpn.entity.${entity.id}.${token}`)(OwnedBehavior);
			const prefab = build(entity, visual, OwnedBehavior, false);
			const displayPrefab = entity.kind === "plant" ? build(entity, visual, OwnedBehavior, true) : null;
			records.set(entity.id, Object.freeze({
				kind: entity.kind,
				engineId: entity.engineId,
				codename: entity.codename,
				behaviorClass: OwnedBehavior,
				entity: prefab,
				display: displayPrefab
			}));
		}
		return Object.freeze({
			get(id) {
				if (state === "disposed") throw new Error("Native entity assets are disposed");
				return records.get(id) || null;
			},
			markInUse() {
				if (state === "disposed") throw new Error("Native entity assets are disposed");
				if (state === "in-use") return false;
				state = "in-use";
				return true;
			},
			dispose
		});
	} catch (error) {
		try {
			dispose();
		} catch (cleanupError) {
			throw new AggregateError([error, cleanupError], "Native entity preparation and cleanup failed");
		}
		throw error;
	}
}
//#endregion
//#region mods/entities/src/entity-native-registration.js
function prepareNativeEntityRegistration({ cc, modules, plan, baseline, prefabs }) {
	const { plants, PlantEnum, Plants } = modules.Plants;
	const { zombies, ZombieEnum, Zombies } = modules.Zombies;
	const objects = modules.JSONs.PvZ2Object;
	const rows = {
		plant: baseline.plantFeatures.PLANTS,
		zombie: baseline.zombieFeatures.ZOMBIES
	};
	const before = {
		plant: JSON.stringify(rows.plant),
		zombie: JSON.stringify(rows.zombie)
	};
	const lists = [{
		data: baseline.plantFeatures,
		field: "SEEDCHOOSERDEFAULTORDER",
		kind: "plant"
	}, {
		data: baseline.zombieFeatures,
		field: "ALMANAC",
		kind: "zombie"
	}].map((entry) => ({
		...entry,
		value: entry.data[entry.field],
		length: entry.data[entry.field]?.length,
		before: JSON.stringify(entry.data[entry.field])
	}));
	const definitions = plan.entities.map((entity) => ({
		...entity,
		feature: structuredClone(entity.feature),
		properties: structuredClone(entity.properties),
		typeRecord: structuredClone(entity.typeRecord)
	}));
	const byId = (kind) => new Map(definitions.filter((entity) => entity.kind === kind).map((entity) => [entity.engineId, entity]));
	const plantIds = byId("plant"), zombieIds = byId("zombie");
	const plantNames = new Map([...plantIds.values()].map((entity) => [entity.codename, entity]));
	const zombieNames = new Map([...zombieIds.values()].map((entity) => [entity.codename, entity]));
	if (typeof plants.getFilledPlantProps !== "function" || typeof zombies.getFilledZombieProps !== "function") throw new Error("Native property constructors are unavailable");
	const prefabMap = new Map(definitions.map((entity) => [entity.id, prefabs.get(entity.id)]));
	for (const entity of definitions) {
		const entry = prefabMap.get(entity.id);
		if (!entry?.entity || entity.kind === "plant" && !entry.display) throw new Error(`Missing prepared native prefabs: ${entity.id}`);
	}
	for (const entry of lists) {
		if (!Array.isArray(entry.value)) throw new Error(`Missing native content list: ${entry.field}`);
		entry.additions = definitions.filter((entity) => entity.kind === entry.kind && entity.listed).map((entity) => {
			if (!entity.almanac?.ready || !entity.almanacRecord?.objdata) throw new Error(`Listed entity needs owned almanac data: ${entity.id}`);
			if (entry.value.includes(entity.codename)) throw new Error(`Duplicate native list entry: ${entity.id}`);
			return entity.codename;
		});
	}
	const writes = [];
	let state = "prepared";
	const cold = () => {
		if (cc.director.getScene() || plants.plantRes || zombies.zombieRes) throw new Error("Entity registration requires a cold startup before native resources");
	};
	const assign = (target, key, value, fresh = false) => {
		const original = Object.getOwnPropertyDescriptor(target, key);
		if (fresh && key in target) throw new Error(`Native entity identity collision: ${key}`);
		if (!original && !Object.isExtensible(target) || original && !original.configurable && (!original.writable || !Object.hasOwn(original, "value"))) throw new Error(`Native registration property is immutable: ${key}`);
		writes.push({
			target,
			key,
			original,
			value
		});
	};
	const wrap = (target, key, choose) => {
		const original = target[key];
		if (typeof original !== "function") throw new Error(`Missing native method: ${key}`);
		assign(target, key, function(...args) {
			const match = choose(...args);
			return match ? match() : original.apply(this, args);
		});
	};
	for (const [kind, enumeration, countKey] of [[
		"plant",
		PlantEnum,
		"amount"
	], [
		"zombie",
		ZombieEnum,
		"zombieAmount"
	]]) {
		if (rows[kind].length !== plan.baselineCounts[kind] || enumeration[countKey] !== rows[kind].length) throw new Error(`Native ${kind} baseline differs from the plan`);
		const entries = definitions.filter((entity) => entity.kind === kind);
		for (const [index, entity] of entries.entries()) {
			if (entity.engineId !== rows[kind].length + index) throw new Error(`Non-contiguous native ${kind} identity`);
			assign(enumeration, entity.codename, entity.engineId, true);
			const previous = enumeration[entity.engineId];
			if (previous !== void 0 && previous !== countKey) throw new Error(`Occupied native ${kind} ID: ${entity.engineId}`);
			assign(enumeration, String(entity.engineId), entity.codename);
		}
		if (entries.length) assign(enumeration, countKey, rows[kind].length + entries.length);
	}
	wrap(plants, "getPlantEnumByCodename", (name) => plantNames.has(name) && (() => plantNames.get(name).engineId));
	wrap(plants, "getPlantProps", (id) => plantIds.has(id) && (() => plantIds.get(id).properties));
	wrap(plants, "getPlantType", (name) => plantNames.has(name) && (() => plantNames.get(name).typeRecord));
	wrap(plants, "getPlantEnumWithPropByPlantTypes", (name) => plantNames.has(name) && (() => {
		const entity = plantNames.get(name);
		return {
			id: entity.engineId,
			prop: plants.getFilledPlantProps(structuredClone(entity.properties), entity.engineId),
			filled_type: structuredClone(entity.typeRecord)
		};
	}));
	wrap(plants, "loadPlantsInCard", (id, disabledOnly) => plantIds.has(id) && (async () => {
		const entry = prefabMap.get(plantIds.get(id).id);
		return {
			plantDIS: entry.display,
			plantPLANT: disabledOnly ? void 0 : entry.entity
		};
	}));
	wrap(zombies, "getZombiePropsByID", (id) => zombieIds.has(id) && (() => zombieIds.get(id).properties));
	wrap(zombies, "getZombieType", (name) => zombieNames.has(name) && (() => zombieNames.get(name).typeRecord));
	wrap(zombies, "getZombieEnumWithPropByZombieTypes", (name) => zombieNames.has(name) && (() => {
		const entity = zombieNames.get(name);
		return {
			z: entity.engineId,
			prop: zombies.getFilledZombieProps(structuredClone(entity.properties), entity.engineId),
			filled_type: structuredClone(entity.typeRecord)
		};
	}));
	wrap(zombies, "loadZombieByID", (id) => zombieIds.has(id) && (async () => prefabMap.get(zombieIds.get(id).id).entity));
	const almanacs = new Map(definitions.filter((entity) => entity.almanac?.ready).map((entity) => [entity.feature.ALMANAC, structuredClone(entity.almanacRecord)]));
	if (typeof objects.getObjects !== "function") throw new Error("Native object filtering is unavailable");
	wrap(objects, "getObjectsByRTID", (rtid, className) => almanacs.has(rtid) && (() => {
		const record = structuredClone(almanacs.get(rtid));
		return objects.getObjects(record.aliases[0], [record], className);
	}));
	for (const [Class, field, expected, kind] of [[
		Plants,
		"CardsFeatureJson",
		baseline.plantFeatures,
		"plant"
	], [
		Zombies,
		"zombieFeaturesJson",
		baseline.zombieFeatures,
		"zombie"
	]]) {
		wrap(Class.prototype, "onLoad", function() {
			return false;
		});
		const write = writes.at(-1);
		const original = Class.prototype.onLoad;
		write.value = function(...args) {
			if (this[field]?.json !== expected || expected[kind === "plant" ? "PLANTS" : "ZOMBIES"] !== rows[kind]) throw new Error(`Native ${kind} feature asset changed after startup preparation`);
			return original.apply(this, args);
		};
	}
	const restore = () => {
		for (const { target, key, original } of [...writes].reverse()) if (original) Object.defineProperty(target, key, original);
		else delete target[key];
		rows.plant.splice(plan.baselineCounts.plant);
		rows.zombie.splice(plan.baselineCounts.zombie);
		for (const entry of lists) entry.value.splice(entry.length);
	};
	return Object.freeze({
		publish() {
			cold();
			if (state !== "prepared") throw new Error("Entity registration was already published or disposed");
			for (const [kind, data, field] of [[
				"plant",
				baseline.plantFeatures,
				"PLANTS"
			], [
				"zombie",
				baseline.zombieFeatures,
				"ZOMBIES"
			]]) if (data[field] !== rows[kind] || JSON.stringify(rows[kind]) !== before[kind]) throw new Error(`Native ${kind} baseline changed during preparation`);
			for (const entry of lists) if (entry.data[entry.field] !== entry.value || JSON.stringify(entry.value) !== entry.before) throw new Error(`Native content list changed: ${entry.field}`);
			for (const { target, key, original } of writes) {
				const current = Object.getOwnPropertyDescriptor(target, key);
				if (Boolean(current) !== Boolean(original) || original && Reflect.ownKeys(original).some((field) => current[field] !== original[field])) throw new Error(`Native method or identity changed: ${key}`);
			}
			try {
				for (const { target, key, original, value } of writes) Object.defineProperty(target, key, original && Object.hasOwn(original, "value") ? {
					...original,
					value
				} : {
					value,
					configurable: true,
					writable: true,
					enumerable: true
				});
				rows.plant.push(...definitions.filter((entity) => entity.kind === "plant").map((entity) => entity.feature));
				rows.zombie.push(...definitions.filter((entity) => entity.kind === "zombie").map((entity) => entity.feature));
				for (const entry of lists) entry.value.push(...entry.additions);
				state = "published";
			} catch (error) {
				try {
					restore();
				} catch (cleanup) {
					throw new AggregateError([error, cleanup], "Native registration and restoration failed");
				}
				state = "disposed";
				throw error;
			}
		},
		markRunning() {
			if (state !== "published") throw new Error("Publish native entities before starting the game");
			prefabs.markInUse();
			state = "running";
		},
		dispose() {
			if (state === "disposed") return false;
			if (state === "running") throw new Error("Restart before removing native entity registration");
			cold();
			if (state === "published") restore();
			state = "disposed";
			return true;
		}
	});
}
//#endregion
//#region mods/entities/src/entity-native-icons.js
function prepareNativeEntityIcons(plan, { modules, decodedOwners }) {
	const visuals = {
		plant: /* @__PURE__ */ new Map(),
		zombie: /* @__PURE__ */ new Map()
	};
	for (const entity of plan.entities) {
		const owner = decodedOwners.get(entity.namespace);
		if (!owner || owner.namespace !== entity.namespace || owner.contentDigest !== entity.contentDigest) throw new Error(`Icon resource identity differs: ${entity.id}`);
		const visual = owner.get(entity.visual);
		if (visual?.kind !== "dragonbones" || !visual.skeleton || !visual.atlas || !visual.armature || !visuals[entity.kind] || visuals[entity.kind].has(entity.engineId)) throw new Error(`Invalid native icon: ${entity.id}`);
		visuals[entity.kind].set(entity.engineId, visual);
	}
	const bindings = /* @__PURE__ */ new WeakMap();
	const rollbackDisplays = /* @__PURE__ */ new Set();
	let state = "prepared";
	const select = (display, visual) => {
		if (!display) throw new Error("Native icon display is unavailable");
		if (visual) {
			if (!bindings.has(display)) {
				bindings.set(display, {
					dragonAsset: display.dragonAsset,
					dragonAtlasAsset: display.dragonAtlasAsset,
					armatureName: display.armatureName
				});
				if (state !== "in-use") rollbackDisplays.add(display);
			}
			display.dragonAsset = visual.skeleton;
			display.dragonAtlasAsset = visual.atlas;
			display.armatureName = visual.armature;
		} else if (bindings.has(display)) {
			const previous = bindings.get(display);
			display.dragonAsset = previous.dragonAsset;
			display.dragonAtlasAsset = previous.dragonAtlasAsset;
			display.armatureName = previous.armatureName;
			bindings.delete(display);
			rollbackDisplays.delete(display);
		}
	};
	const targetVisual = (kind, target) => {
		const amount = plan.baselineCounts[kind] + visuals[kind].size;
		const id = Number.isFinite(target) ? (target % amount + amount) % amount : target;
		return visuals[kind].get(id);
	};
	const hooks = [];
	const hook = (Class, key, make) => {
		const target = Class?.prototype;
		const original = target && Object.getOwnPropertyDescriptor(target, key);
		if (!original?.configurable) throw new Error(`Native icon hook unavailable: ${key}`);
		const installed = make(original);
		hooks.push({
			target,
			key,
			original,
			installed
		});
	};
	hook(modules.CardFeature, "cardGrouperPlant", (original) => {
		if (typeof original.value !== "function") throw new Error("Native plant card method unavailable");
		return {
			...original,
			value: function(id = this.ID, ...rest) {
				select(this.ca._plantDB, targetVisual("plant", id));
				return original.value.call(this, id, ...rest);
			}
		};
	});
	hook(modules.PlantIcon, "switchPlant", (original) => {
		if (typeof original.value !== "function") throw new Error("Native plant icon method unavailable");
		return {
			...original,
			value: function(id, ...rest) {
				select(this.plantDB, visuals.plant.get(id));
				return original.value.call(this, id, ...rest);
			}
		};
	});
	const unknown = Object.getOwnPropertyDescriptor(modules.CardFeatureZombie?.prototype || {}, "isUnknown");
	if (typeof unknown?.set !== "function") throw new Error("Native zombie unknown setter unavailable");
	hook(modules.CardFeatureZombie, "cardGrouperZombie", (original) => {
		if (typeof original.value !== "function") throw new Error("Native zombie card method unavailable");
		return {
			...original,
			value: function(id = this.ID, ...rest) {
				select(this.ca._plantDB, targetVisual("zombie", id));
				const result = original.value.call(this, id, ...rest);
				if (this.isUnknown) {
					select(this.ca._plantDB, null);
					unknown.set.call(this, true);
				}
				return result;
			}
		};
	});
	hook(modules.CardFeatureZombie, "isUnknown", (original) => ({
		...original,
		set: function(value) {
			if (value) select(this.ca._plantDB, null);
			return original.set.call(this, value);
		}
	}));
	const matches = (a, b) => a && [
		"value",
		"get",
		"set",
		"configurable",
		"enumerable",
		"writable"
	].every((key) => a[key] === b[key]);
	const releaseMedia = [];
	try {
		for (const entity of plan.entities) releaseMedia.push(decodedOwners.get(entity.namespace).retain({
			entityId: entity.id,
			kind: "native-icon",
			resourceIds: [entity.visual]
		}));
	} catch (error) {
		for (const release of releaseMedia) release();
		throw error;
	}
	return Object.freeze({
		install() {
			if (state === "disposed") throw new Error("Native icon adapter is disposed");
			if (state !== "prepared") return false;
			for (const item of hooks) if (!matches(Object.getOwnPropertyDescriptor(item.target, item.key), item.original)) throw new Error(`Native icon hook changed: ${item.key}`);
			const applied = [];
			try {
				for (const item of hooks) {
					Object.defineProperty(item.target, item.key, item.installed);
					applied.push(item);
				}
			} catch (error) {
				for (const item of applied.reverse()) Object.defineProperty(item.target, item.key, item.original);
				throw error;
			}
			state = "installed";
			return true;
		},
		markInUse() {
			if (state === "in-use") return false;
			if (state !== "installed") throw new Error("Install native icon routes before publication");
			state = "in-use";
			rollbackDisplays.clear();
			return true;
		},
		dispose() {
			if (state === "in-use") throw Object.assign(/* @__PURE__ */ new Error("Published native icon routes require restart"), { code: "ENTITY_RESTART_REQUIRED" });
			if (state === "disposed") return false;
			if (state === "installed") {
				for (const item of hooks) if (!matches(Object.getOwnPropertyDescriptor(item.target, item.key), item.installed)) throw new Error(`Native icon hook ownership lost: ${item.key}`);
				for (const display of rollbackDisplays) select(display, null);
				for (const item of [...hooks].reverse()) Object.defineProperty(item.target, item.key, item.original);
			}
			state = "disposed";
			visuals.plant.clear();
			visuals.zombie.clear();
			for (const release of releaseMedia.splice(0)) release();
			return true;
		}
	});
}
//#endregion
//#region mods/entities/src/startup-native-data.js
async function loadStartupNativeData(cc, { signal } = {}) {
	const assertCold = () => {
		signal?.throwIfAborted();
		if (cc.director.getScene()) throw new Error("Native data preparation requires a cold startup");
	};
	assertCold();
	const bundle = await new Promise((resolve, reject) => cc.assetManager.loadBundle("resources", (error, value) => error ? reject(error) : resolve(value)));
	assertCold();
	const entries = [
		[
			"plantFeatures",
			"json/Features/PlantFeatures",
			"PLANTS"
		],
		[
			"zombieFeatures",
			"json/Features/ZombieFeatures",
			"ZOMBIES"
		],
		[
			"plantProps",
			"json/Objects/PlantProps",
			"objects"
		],
		[
			"zombieProps",
			"json/Objects/ZombieProps",
			"objects"
		],
		[
			"plantTypes",
			"json/Objects/PlantTypes",
			"objects"
		],
		[
			"plantAlmanac",
			"json/Objects/PlantAlmanac",
			"objects"
		]
	];
	const data = {};
	for (const [key, path, field] of entries) {
		const asset = await new Promise((resolve, reject) => bundle.load(path, cc.JsonAsset, (error, value) => error ? reject(error) : resolve(value)));
		assertCold();
		if (!Array.isArray(asset?.json?.[field])) throw new Error(`Invalid native startup data: ${path}`);
		data[key] = asset.json;
	}
	return Object.freeze(data);
}
//#endregion
//#region mods/entities/src/main.js
var main_default = {
	startup(ctx) {
		const cc = ctx.engine.getCc();
		const module = (name) => ctx.engine.getSystemModule(`chunks:///_virtual/${name}.ts`);
		const modules = {
			Plants: module("Plants"),
			Zombies: module("Zombies"),
			JSONs: module("JSONs"),
			CardFeature: module("CardFeature").CardFeature,
			PlantIcon: module("PlantIcon").PlantIcon,
			CardFeatureZombie: module("CardFeatureZombie").CardFeatureZombie,
			native: {
				Plant: module("Plant").Plant,
				Zombie: module("Zombie").Zombie,
				AnimationController: module("AnimationController").AnimationController,
				BodyGrouper: module("BodyGrouper").BodyGrouper,
				PrefabInfo: cc.js.getClassByName("cc.PrefabInfo")
			}
		};
		const behaviors = /* @__PURE__ */ new Map(), owners = /* @__PURE__ */ new Map();
		let baseline, plan, prefabs, icons, registration;
		let accepting = true;
		ctx.registry.provide("entities", Object.freeze({ registerBehavior(namespace, id, factory) {
			if (!accepting) throw new Error("Entity behavior registration is closed");
			if (typeof factory !== "function") throw new Error("Expected behavior factory");
			const key = `${namespace}:${id}`;
			if (behaviors.has(key)) throw new Error(`Duplicate behavior: ${key}`);
			behaviors.set(key, factory);
		} }));
		ctx.registrations.add("entities", {
			async prepare({ previousIdentities, identities }) {
				accepting = false;
				const descriptors = [];
				for (const reader of ctx.files.contributions()) {
					const bytes = new Map(await Promise.all(reader.listPaths().map(async (path) => [path, await reader.readBytes(path)])));
					const snapshot = {
						digest: reader.contentDigest,
						readBytes: (path) => bytes.get(path) || null,
						readText: (path) => bytes.has(path) ? new TextDecoder().decode(bytes.get(path)) : null
					};
					const descriptor = prepareEntityContent({ meta: JSON.parse(snapshot.readText("pack.json")) }, snapshot);
					if (descriptor) descriptors.push(descriptor);
				}
				baseline = await loadStartupNativeData(cc);
				plan = planNativeEntities({
					preparedDescriptors: descriptors,
					baseline,
					previousLedger: previousIdentities,
					dataLedger: identities
				});
				for (const descriptor of descriptors) owners.set(descriptor.namespace, await decodeEntityContentResources(descriptor, { cc }));
				prefabs = prepareNativeEntityAssets(plan, {
					cc,
					native: modules.native,
					decodedOwners: owners,
					behaviorFactories: behaviors
				});
				icons = prepareNativeEntityIcons(plan, {
					modules,
					decodedOwners: owners
				});
				return { identities: plan.ledger.filter((entry) => !identities.some((prior) => prior.id === entry.id)) };
			},
			publish() {
				registration = prepareNativeEntityRegistration({
					cc,
					modules,
					plan,
					baseline,
					prefabs
				});
				registration.publish();
				icons.install();
				registration.markRunning();
				icons.markInUse();
				prefabs.markInUse();
			},
			async dispose() {
				const errors = [];
				for (const dispose of [
					() => icons?.dispose(),
					() => registration?.dispose(),
					() => prefabs?.dispose(),
					...[...owners.values()].reverse().map((owner) => () => owner.dispose())
				]) try {
					await dispose();
				} catch (error) {
					errors.push(error);
				}
				if (errors.length) throw new AggregateError(errors, "Entity framework cleanup failed");
			},
			getResources: () => [...owners.values()].map((owner) => owner.getConsumers())
		});
	},
	setup() {}
};
//#endregion
export { main_default as default };
